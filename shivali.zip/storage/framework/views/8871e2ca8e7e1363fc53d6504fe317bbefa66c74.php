<?php $__env->startSection('title','Product Images'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content">
  <div class="page-content">
    <div class="container-fluid">
      <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">Images: <?php echo e($product->product_name); ?></h4>
        <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-light">Back</a>
      </div>

      <div class="card mb-3">
        <div class="card-header"><h5>Upload Images</h5></div>
        <div class="card-body">
         <form method="POST" action="<?php echo e(route('admin.product-images.store', $product->product_id)); ?>" enctype="multipart/form-data">
       <?php echo csrf_field(); ?>
        <input type="file" name="images[]" multiple class="form-control mb-3" accept="image/*">
        <button type="submit" class="btn btn-success">Upload</button>
    </form>

        </div>
      </div>

      <div class="card">
        <div class="card-header"><h5>Existing Images</h5></div>
        <div class="card-body">

          <?php if($images->isEmpty()): ?>
            <p class="text-muted">No images uploaded yet.</p>
          <?php else: ?>
          <form method="POST" action="<?php echo e(route('admin.product-images.delete', $product->product_id)); ?>" onsubmit="return confirm('Delete all images?')">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-danger btn-sm">Delete All</button>
                    </form>
            <div class="row g-3">
              <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-6 col-sm-3 col-md-2">
                <div class="border rounded p-2 text-center">
                  <img src="<?php echo e(asset($img->image)); ?>" alt="img" class="img-fluid rounded mb-2" style="height:100px;object-fit:cover;">
                  <form method="POST" action="<?php echo e(route('admin.product-images.deleteOne', $img->pimage_id)); ?>" onsubmit="return confirm('Delete this image?')">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-sm btn-danger w-100">Delete</button>
                      </form>

                          

                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>
        </div>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/shivali/resources/views/admin/product/images.blade.php ENDPATH**/ ?>