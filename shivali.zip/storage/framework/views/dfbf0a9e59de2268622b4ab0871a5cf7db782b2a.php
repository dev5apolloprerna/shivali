<?php $__env->startSection('title', 'Sub Category'); ?>

<?php $__env->startSection('content'); ?>

    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">

                
                <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="row">
                    <!-- Left side - Add Form -->
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title mb-0">Add Sub Category</h4>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('admin.sub-category.store')); ?>" id="subCategoryForm"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <div class="mb-3">
                                        <label for="iCategoryId" class="form-label">Category <span
                                                class="text-danger">*</span></label>
                                        <select name="iCategoryId" id="iCategoryId" class="form-control" required>
                                            <option value="">Select Category</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="strSubCategoryName" class="form-label">Sub Category Name <span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="strSubCategoryName"
                                            name="strSubCategoryName" maxlength="50" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="strCategoryName" class="form-label">Sub Category Image </label>
                                        <input type="file" class="form-control" id="subcategoryimg"
                                            name="subcategory_img" maxlength="50">
                                    </div>

                                    <!-- <div class="mb-3">
                                                                                                                <label for="strSlug" class="form-label">Slug <span class="text-danger">*</span></label>
                                                                                                                <input type="text" class="form-control" id="strSlug" name="strSlug" maxlength="50" required>
                                                                                                            </div> -->

                                    <div class="d-flex">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                        <button type="reset" class="btn btn-light">Clear</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Right side - Listing -->
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <h4 class="card-title mb-0">Sub Category Listing</h4>
                                <button type="button" id="bulkDeleteBtn" class="btn btn-danger btn-sm">
                                    <i class="fas fa-trash"></i> Delete All
                                </button>
                            </div>
                            <div class="card-body">
                                <form method="POST" id="bulkDeleteForm"
                                    action="<?php echo e(route('admin.sub-category.bulk-delete')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <table class="table table-bordered table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <input type="checkbox" id="selectAll">
                                                </th>
                                                <th>Category</th>
                                                <th>Sub Category Name</th>
                                                <th>Sub Category Image</th>
                                                <!-- <th>Slug</th> -->
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td>
                                                        <input type="checkbox" name="ids[]"
                                                            value="<?php echo e($subcategory->iSubCategoryId); ?>">
                                                    </td>
                                                    <td><?php echo e($subcategory->category->strCategoryName ?? '-'); ?></td>
                                                    <td><?php echo e($subcategory->strSubCategoryName); ?></td>
                                                    <td>
                                                        <?php if($subcategory->subcategory_img): ?>
                                                            <img src="<?php echo e(asset('uploads/subcategory-images/' . $subcategory->subcategory_img)); ?>"
                                                                style="width:70px;height:50px;object-fit:cover;border-radius:4px;">
                                                        <?php else: ?>
                                                            <img src="<?php echo e(asset('assets/images/noimage.png')); ?>"
                                                                style="width:70px;height:50px;object-fit:cover;border-radius:4px;">
                                                        <?php endif; ?>
                                                    </td>
                                                    <!-- <td><?php echo e($subcategory->strSlug); ?></td> -->
                                                    <td>
                                                        <button type="button" class="btn btn-sm btn-warning edit-btn"
                                                            data-id="<?php echo e($subcategory->iSubCategoryId); ?>"
                                                            data-category="<?php echo e($subcategory->iCategoryId); ?>"
                                                            data-name="<?php echo e($subcategory->strSubCategoryName); ?>"
                                                            data-image="<?php echo e($subcategory->subcategory_img); ?>"
                                                            data-slug="<?php echo e($subcategory->strSlug); ?>">
                                                            <i class="fas fa-edit"></i>
                                                        </button>
                                                        <form method="POST"
                                                            action="<?php echo e(route('admin.sub-category.destroy', $subcategory->iSubCategoryId)); ?>"
                                                            style="display:inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-sm btn-danger"
                                                                onclick="return confirm('Are you sure you want to delete this record?')">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="5">No records found.</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </form>

                                <?php echo e($subcategories->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>

            </div> <!-- container-fluid -->
        </div> <!-- page-content -->
    </div> <!-- main-content -->

    <div class="modal fade" id="editSubCategoryModal" tabindex="-1" aria-labelledby="editSubCategoryModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" id="editSubCategoryForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Sub Category</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <input type="hidden" name="id" id="editSubCategoryId">

                        <div class="mb-3">
                            <label for="editICategoryId" class="form-label">Category <span
                                    class="text-danger">*</span></label>
                            <select name="iCategoryId" id="editICategoryId" class="form-control" required>
                                <option value="">Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="editStrSubCategoryName" class="form-label">Sub Category Name <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="editStrSubCategoryName"
                                name="strSubCategoryName" maxlength="50" required>
                        </div>

                        <div class="mb-3">
                            <label for="editStrCategoryimage" class="form-label">Sub Category Image <span
                                    class="text-danger">*</span></label>
                            <!-- Change this to a file input -->
                            <input type="file" class="form-control" id="editStrCategoryimage" name="subcategory_img">
                            <input type="hidden" name="hiddenimagePhoto" id="hiddenimagePhoto" value="">

                            <div class="mt-2">
                                <!-- Display current image preview -->
                                <img class="img-fluid" src="" alt="Current Image" height="50" width="50"
                                    id="Edit_home_CategoryImage">
                            </div>
                        </div>

                        <!--  <div class="mb-3">
                                                                                                    <label for="editStrSlug" class="form-label">Slug <span class="text-danger">*</span></label>
                                                                                                    <input type="text" class="form-control" id="editStrSlug" name="strSlug" maxlength="50" required>
                                                                                                </div> -->

                    </div>
                    <div class="modal-footer d-flex ">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('common.footerjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        // Edit button click
        $('.edit-btn').on('click', function() {
            let id = $(this).data('id');
            let category = $(this).data('category');
            let name = $(this).data('name');
            let slug = $(this).data('slug');
            let image = $(this).data('image');


            $('#editSubCategoryId').val(id);
            $('#editICategoryId').val(category);
            $('#editStrSubCategoryName').val(name);
            $('#editStrSlug').val(slug);

            // ✅ Build correct image URL
            var imageUrl = image ?
                "<?php echo e(asset('uploads/subcategory-images')); ?>/" + image :
                "<?php echo e(asset('assets/images/noimage.png')); ?>";

            // ✅ Set preview and hidden image field
            $('#Edit_home_CategoryImage').attr('src', imageUrl);
            $('#hiddenimagePhoto').val(image);

            // ✅ Set form action dynamically
            $('#editSubCategoryForm').attr('action', "<?php echo e(url('admin/sub-category')); ?>/" + id);


            // $('#editSubCategoryForm').attr('action', '/Shivali/admin/sub-category/' + id);
            $('#editSubCategoryModal').modal('show');
        });

        // Bulk delete
        $('#bulkDeleteBtn').on('click', function() {
            if (confirm('Are you sure you want to delete selected records?')) {
                $('#bulkDeleteForm').submit();
            }
        });

        // Select all checkbox
        $('#selectAll').on('click', function() {
            $('input[name="ids[]"]').prop('checked', this.checked);
        });


        (function() {
            function toSlug(s) {
                return (s || '')
                    .toString()
                    .normalize('NFKD')
                    .replace(/[\u0300-\u036f]/g, '')
                    .toLowerCase()
                    .replace(/[^a-z0-9]+/g, '-')
                    .replace(/^-+|-+$/g, '')
                    .substring(0, 50);
            }

            // Create form elements
            const nameEl = document.getElementById('strSubCategoryName');
            const slugEl = document.getElementById('strSlug');

            // Edit modal elements
            const editNameEl = document.getElementById('editStrSubCategoryName');
            const editSlugEl = document.getElementById('editStrSlug');

            let userEditedCreateSlug = false;
            let userEditedEditSlug = false;

            slugEl?.addEventListener('input', () => userEditedCreateSlug = true);
            editSlugEl?.addEventListener('input', () => userEditedEditSlug = true);

            nameEl?.addEventListener('input', function() {
                if (!userEditedCreateSlug) slugEl.value = toSlug(this.value);
            });

            editNameEl?.addEventListener('input', function() {
                if (!userEditedEditSlug) editSlugEl.value = toSlug(this.value);
            });

            // If slug empty on load, prime it from name once
            if (nameEl && slugEl && !slugEl.value) slugEl.value = toSlug(nameEl.value);
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/shivali/resources/views/admin/sub-category/index.blade.php ENDPATH**/ ?>