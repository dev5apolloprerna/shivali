<?php
if (auth()->user()) {
    $roleid = auth()->user()->role_id;
} else {
    $roleid = Auth::guard('web_employees')->user()->role_id;
}
?>
<!-- ========== App Menu ========== -->
<div class="app-menu navbar-menu">
    <div id="scrollbar">
        <div class="container-fluid">
            <div id="two-column-menu"></div>
            <ul class="navbar-nav" id="navbar-nav">
                <li class="menu-title"><span data-key="t-menu"></span></li>
                <li class="nav-item">
                    <a class="nav-link menu-link <?php if(request()->routeIs('home')): ?> <?php echo e('active'); ?> <?php endif; ?>"
                        href="<?php echo e(route('home')); ?>">
                        <i class="mdi mdi-speedometer"></i>
                        <span data-key="t-dashboards">Dashboards</span>
                    </a>
                </li>
                <?php if($roleid == '1' && $roleid != '2'): ?>
                    <!-- Category -->
                    <li class="nav-item">
                        <a class="nav-link menu-link <?php if(request()->routeIs('admin.category.*')): ?> active <?php endif; ?>"
                            href="<?php echo e(route('admin.category.index')); ?>">
                            <i class="fas fa-folder"></i>
                            <span data-key="t-category">Category</span>
                        </a>
                    </li>

                    <!-- Sub Category -->
                    <li class="nav-item">
                        <a class="nav-link menu-link <?php if(request()->routeIs('admin.sub-category.*')): ?> active <?php endif; ?>"
                            href="<?php echo e(route('admin.sub-category.index')); ?>">
                            <i class="fas fa-folder-open"></i>
                            <span data-key="t-sub-category">Sub Category</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link menu-link <?php if(request()->routeIs('admin.products.index')): ?> <?php echo e('active'); ?> <?php endif; ?>"
                            href="<?php echo e(route('admin.products.index')); ?>">
                            <i class="fa-solid fa-circle-question"></i>
                            <span data-key="t-dashboards">Product</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link menu-link <?php if(request()->routeIs('Inquiry.index')): ?> <?php echo e('active'); ?> <?php endif; ?>"
                            href="<?php echo e(route('Inquiry.index')); ?>">
                            <i class="fa-solid fa-circle-question"></i>
                            <span data-key="t-dashboards">Inquiry</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link menu-link <?php if(request()->routeIs('TopVideo.index')): ?> <?php echo e('active'); ?> <?php endif; ?>"
                            href="<?php echo e(route('TopVideo.index')); ?>">
                            <i class="fa-solid fa-play-circle"></i>
                            <span data-key="t-dashboards">Top Video</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link menu-link <?php if(request()->routeIs('BottomVideo.index')): ?> <?php echo e('active'); ?> <?php endif; ?>"
                            href="<?php echo e(route('BottomVideo.index')); ?>">
                            <i class="fa-solid fa-play-circle"></i>
                            <span data-key="t-dashboards">Bottom Video</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link menu-link <?php if(request()->routeIs('Banner.index')): ?> <?php echo e('active'); ?> <?php endif; ?>"
                            href="<?php echo e(route('Banner.index')); ?>">
                            <i class="fa-solid fa-play-circle"></i>
                            <span data-key="t-dashboards">Banner</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>

    <div class="sidebar-background"></div>
</div>
<?php /**PATH /var/www/html/shivali/resources/views/common/sidebar.blade.php ENDPATH**/ ?>