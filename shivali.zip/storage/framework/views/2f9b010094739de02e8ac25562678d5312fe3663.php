<?php $__env->startSection('title', 'Category'); ?>

<?php $__env->startSection('content'); ?>

    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">

                
                <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="row">
                    <!-- Left side - Add Form -->
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title mb-0">Add Category</h4>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('admin.category.store')); ?>" id="categoryForm"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <div class="mb-3">
                                        <label for="strCategoryName" class="form-label">Category Name <span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="strCategoryName"
                                            name="strCategoryName" maxlength="50" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="strCategoryName" class="form-label">Category Image </label>
                                        <input type="file" class="form-control" id="categoryimg" name="category_img"
                                            maxlength="50">
                                    </div>

                                    <!-- <div class="mb-3">
                                                                                                                                                                                                            <label for="strSlug" class="form-label">Slug <span class="text-danger">*</span></label>
                                                                                                                                                                                                            <input type="text" class="form-control" id="strSlug" name="strSlug" maxlength="50" required>
                                                                                                                                                                                                        </div> -->

                                    <div class="d-flex ">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                        <button type="reset" class="btn btn-light">Clear</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Right side - Listing -->
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <h4 class="card-title mb-0">Category Listing</h4>
                                <button type="button" id="bulkDeleteBtn" class="btn btn-danger btn-sm">
                                    <i class="fas fa-trash"></i> Delete All
                                </button>
                            </div>
                            <div class="card-body">
                                <!-- <form method="POST" id="bulkDeleteForm" action="<?php echo e(route('admin.category.bulk-delete')); ?>">
                                                                                                                                                                                                        <?php echo csrf_field(); ?> -->
                                <table class="table table-bordered table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>
                                                <input type="checkbox" id="selectAll">
                                            </th>
                                            <th>Category Name</th>
                                            <th>Slug</th>
                                            <th>Category Image</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td>
                                                    <input type="checkbox" name="ids[]"
                                                        value="<?php echo e($category->iCategoryId); ?>">
                                                </td>
                                                <td><?php echo e($category->strCategoryName); ?></td>
                                                <td><?php echo e($category->strSlug); ?></td>
                                                <td>
                                                    <?php if($category->category_img): ?>
                                                        <img src="<?php echo e(asset('uploads/category-images/' . $category->category_img)); ?>"
                                                            style="width:70px;height:50px;object-fit:cover;border-radius:4px;">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('assets/images/noimage.png')); ?>"
                                                            style="width:70px;height:50px;object-fit:cover;border-radius:4px;">
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <button type="button" class="btn btn-sm btn-warning edit-btn"
                                                        data-id="<?php echo e($category->iCategoryId); ?>"
                                                        data-name="<?php echo e($category->strCategoryName); ?>"
                                                        data-image="<?php echo e($category->category_img); ?>"
                                                        data-slug="<?php echo e($category->strSlug); ?>">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <form method="POST"
                                                        action="<?php echo e(route('admin.category.destroy', $category->iCategoryId)); ?>"
                                                        style="display:inline;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-danger"
                                                            onclick="return confirm('Are you sure you want to delete this record?')">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="4">No records found.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                                <!-- </form> -->

                                <?php echo e($categories->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>

            </div> <!-- container-fluid -->
        </div> <!-- page-content -->
    </div> <!-- main-content -->

    <!-- Edit Modal -->
    <div class="modal fade" id="editCategoryModal" tabindex="-1" aria-labelledby="editCategoryModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" id="editCategoryForm" enctype="multipart/form-data" action="">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Category</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <input type="hidden" name="id" id="editCategoryId">

                        <div class="mb-3">
                            <label for="editStrCategoryName" class="form-label">Category Name <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="editStrCategoryName" name="strCategoryName"
                                maxlength="50" required>
                        </div>

                        <div class="mb-3">
                            <label for="editStrCategoryimage" class="form-label">Category Image <span
                                    class="text-danger">*</span></label>
                            <!-- Change this to a file input -->
                            <input type="file" class="form-control" id="editStrCategoryimage" name="category_img">
                            <input type="hidden" name="hiddenimagePhoto" id="hiddenimagePhoto" value="">

                            <div class="mt-2">
                                <!-- Display current image preview -->
                                <img class="img-fluid" src="" alt="Current Image" height="50" width="50"
                                    id="Edit_home_CategoryImage">
                            </div>
                        </div>

                        <!-- <div class="mb-3">
                                                                                                                                                                                                <label for="editStrSlug" class="form-label">Slug <span class="text-danger">*</span></label>
                                                                                                                                                                                                <input type="text" class="form-control" id="editStrSlug" name="strSlug" maxlength="50" required>
                                                                                                                                                                                            </div> -->
                    </div>
                    <div class="modal-footer d-flex">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('common.footerjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        // Edit button click
        $('.edit-btn').on('click', function() {
            let id = $(this).data('id');
            let name = $(this).data('name');
            let slug = $(this).data('slug');
            let image = $(this).data('image');

            // Fill the modal fields
            $('#editCategoryId').val(id);
            $('#editStrCategoryName').val(name);
            $('#editStrSlug').val(slug);

            // ✅ Build correct image URL
            var imageUrl = image ?
                "<?php echo e(asset('uploads/category-images')); ?>/" + image :
                "<?php echo e(asset('assets/images/noimage.png')); ?>";

            // ✅ Set preview and hidden image field
            $('#Edit_home_CategoryImage').attr('src', imageUrl);
            $('#hiddenimagePhoto').val(image);

            // ✅ Set form action dynamically
            $('#editCategoryForm').attr('action', "<?php echo e(url('admin/category')); ?>/" + id);

            // Show modal
            $('#editCategoryModal').modal('show');
        });

        // Bulk delete
        /*$('#bulkDeleteBtn').on('click', function() {
            if(confirm('Are you sure you want to delete selected records?')) {
                $('#bulkDeleteForm').submit();
            }
        });*/

        $('#bulkDeleteBtn').on('click', function() {
            var ids = $('input[name="ids[]"]:checked').map(function() {
                return $(this).val();
            }).get();

            if (ids.length === 0) {
                alert("Please select at least one record to delete.");
                return;
            }

            if (confirm('Are you sure you want to delete selected records?')) {
                $.ajax({
                    url: "<?php echo e(route('admin.category.bulk-delete')); ?>",
                    type: "POST",
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        ids: ids
                    },
                    success: function(response) {
                        alert('Deleted successfully.');
                        location.reload();
                    },
                    error: function(xhr) {
                        alert('An error occurred.');
                    }
                });
            }
        });


        // Select all checkbox
        $('#selectAll').on('click', function() {
            $('input[name="ids[]"]').prop('checked', this.checked);
        });

        (function() {
            function toSlug(s) {
                return (s || '')
                    .toString()
                    .normalize('NFKD') // handle accents
                    .replace(/[\u0300-\u036f]/g, '') // strip diacritics
                    .toLowerCase()
                    .replace(/[^a-z0-9]+/g, '-') // non-alnum -> hyphen
                    .replace(/^-+|-+$/g, '') // trim dashes
                    .substring(0, 50); // keep within your maxlength
            }

            const nameEl = document.getElementById('strCategoryName');
            const slugEl = document.getElementById('strSlug');
            const editNameEl = document.getElementById('editStrCategoryName');
            const editSlugEl = document.getElementById('editStrSlug');

            let userEditedCreateSlug = false;
            let userEditedEditSlug = false;

            // If user types in slug manually, stop auto-sync for that form
            slugEl?.addEventListener('input', () => userEditedCreateSlug = true);
            editSlugEl?.addEventListener('input', () => userEditedEditSlug = true);

            // Create form: name -> slug (only if user hasn't touched slug)
            nameEl?.addEventListener('input', function() {
                if (!userEditedCreateSlug) slugEl.value = toSlug(this.value);
            });

            // Edit modal: name -> slug (only if user hasn't touched slug)
            editNameEl?.addEventListener('input', function() {
                if (!userEditedEditSlug) editSlugEl.value = toSlug(this.value);
            });

            // If the form loads with empty slug, prime it from name once
            if (nameEl && slugEl && !slugEl.value) slugEl.value = toSlug(nameEl.value);
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/shivali/resources/views/admin/category/index.blade.php ENDPATH**/ ?>