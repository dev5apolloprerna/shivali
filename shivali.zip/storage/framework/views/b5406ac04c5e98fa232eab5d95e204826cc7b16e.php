<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="mb-0">Products</h4>
                    <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-sm btn-primary">Add Product</a>
                </div>

                <div class="card shadow-sm">
                    <div class="card-header">
                        <form class="row g-2 align-items-center" method="GET" action="<?php echo e(route('admin.products.index')); ?>">
                            <div class="col-md-3">
                                <input type="text" name="q" value="<?php echo e($q); ?>" class="form-control"
                                    placeholder="Search name/slug/desc">
                            </div>
                            <div class="col-md-3">
                                <select name="category_id" class="form-select">
                                    <option value="">All Categories</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($id); ?>" <?php if($categoryId == $id): echo 'selected'; endif; ?>><?php echo e($name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select name="subcategory_id" class="form-select">
                                    <option value="">All Subcategories</option>
                                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($id); ?>" <?php if($subcatId == $id): echo 'selected'; endif; ?>><?php echo e($name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-3 d-flex gap-2">
                                <button class="btn btn-secondary" type="submit">Filter</button>
                                <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-light">Reset</a>
                            </div>
                        </form>
                    </div>

                    <div class="card-body table-responsive">
                        <table class="table align-middle">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Image</th>
                                    <th>Name / Slug</th>
                                    <th>Category</th>
                                    <th>Status</th>
                                    <th style="width:190px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($list->firstItem() + $i); ?></td>
                                        <td>
                                            <?php if($p->product_image): ?>
                                                <img src="<?php echo e(asset($p->product_image)); ?>"
                                                    style="width:70px;height:50px;object-fit:cover;border-radius:4px;">
                                            <?php else: ?>
                                                —
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="fw-semibold"><?php echo e($p->product_name); ?></div>
                                            <div class="text-muted small"><?php echo e($p->slug); ?></div>
                                        </td>
                                        <td class="small">
                                            <?php echo e($p->category->strCategoryName ?? '—'); ?> /
                                            <?php echo e($p->subcategory->strSubCategoryName ?? '—'); ?>

                                        </td>
                                        <td>
                                            <form method="POST"
                                                action="<?php echo e(route('admin.products.toggle-status', $p->product_id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button
                                                    class="btn btn-sm <?php echo e($p->iStatus ? 'btn-success' : 'btn-outline-secondary'); ?>"
                                                    type="submit">
                                                    <?php echo e($p->iStatus ? 'Active' : 'Inactive'); ?>

                                                </button>
                                            </form>
                                        </td>
                                        <td class="d-flex gap-2">
                                            <a href="<?php echo e(route('admin.products.edit', $p->product_id)); ?>"
                                                class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>

                                            <a href="<?php echo e(route('admin.products.bestproduct', $p->product_id)); ?>"
                                                class="btn btn-sm btn-primary">
                                                <?php echo $p->best_product ? '<i class="fa-solid fa-crown"></i>' : '<i class="fa-solid fa-trophy"></i>'; ?>

                                            </a>


                                            <a href="<?php echo e(route('admin.product-images.index', $p->product_id)); ?>"
                                                class="btn btn-sm btn-success" title="Add Images">
                                                <i class="fa fa-plus"></i>
                                            </a>

                                            <a href="<?php echo e(route('admin.product-videos.index', $p->product_id)); ?>"
                                                class="btn btn-sm btn-outline-primary" title="Add Videos"><i
                                                    class="fa fa-video"></i></a>


                                            <form method="POST"
                                                action="<?php echo e(route('admin.products.delete', $p->product_id)); ?>"
                                                onsubmit="return confirm('Delete this product?')" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted">No records.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="mt-3"><?php echo e($list->links()); ?></div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/shivali/resources/views/admin/product/index.blade.php ENDPATH**/ ?>