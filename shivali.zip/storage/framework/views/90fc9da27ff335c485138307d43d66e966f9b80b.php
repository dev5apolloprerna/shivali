<?php $__env->startSection('title','Product Videos'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content">
  <div class="page-content">
    <div class="container-fluid">
      <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">Videos: <?php echo e($product->product_name); ?></h4>
        <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-light">Back</a>
      </div>

      <div class="card mb-3">
        <div class="card-header"><h5>Add Video Link</h5></div>
        <div class="card-body">
          <form method="POST" action="<?php echo e(route('admin.product-videos.store', $product->product_id)); ?>">
            <?php echo csrf_field(); ?>
            <div class="row g-3">
              <div class="col-md-8">
                <input type="text" name="video_link" value="<?php echo e(old('video_link')); ?>"
                       class="form-control <?php $__errorArgs = ['video_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       placeholder="Enter YouTube or Vimeo link">
                <?php $__errorArgs = ['video_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="col-md-4 d-grid">
                <button type="submit" class="btn btn-primary">Add Video</button>
              </div>
            </div>
          </form>
        </div>
      </div>

      <div class="card">
        <div class="card-header"><h5>Video List</h5></div>
        <div class="card-body">
          <?php if($videos->isEmpty()): ?>
            <p class="text-muted">No videos added yet.</p>
          <?php else: ?>
            <div class="row g-3">
              <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-6 col-lg-4">
                <div class="border rounded p-2 h-100">
                  <!-- <div class="ratio ratio-16x9 mb-2"> -->
                    <a href="<?php echo e($vid->video_link); ?>"  target="_blank"><?php echo e($vid->video_link); ?></a>
                  <!-- </div> -->
                  <form method="POST" action="<?php echo e(route('admin.product-videos.deleteOne', $vid->pvideo_id)); ?>" onsubmit="return confirm('Delete this video?')">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-sm btn-danger w-100">Delete</button>
                  </form>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>
        </div>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/shivali/resources/views/admin/product/videos.blade.php ENDPATH**/ ?>