<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb -->
    <section class="page-title text-center">
        <div class="container">
            <h3 class="heading mb-2">Product Details</h3>
            <ul class="breadcrumbs d-flex justify-content-center align-items-center">
                <li><a href="<?php echo e(url('/')); ?>" class="link">Home</a></li>
                <li><i class="fa fa-arrow-right mx-2"></i></li>
                <li><?php echo e($product->product_name); ?></li>
            </ul>
        </div>
    </section>

    <section class="product-detail py-5">
        <div class="container">
            <div class="row g-5">

                <!-- Product Images -->
                <div class="col-lg-5">
                    <div class="product-gallery d-flex">
                        <div class="thumb-list d-flex flex-column me-3">
                            <?php $__currentLoopData = $product->productimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e(asset($img->image)); ?>" alt="Thumbnail" onclick="changeImage(this);"
                                    class="<?php echo e($loop->first ? 'active' : ' '); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="main-image flex-grow-1">
                            <img id="mainProductImage" src="<?php echo e(asset($product->product_image ?? 'no-image.jpg')); ?>"
                                alt="<?php echo e($product->product_name); ?>">
                        </div>
                    </div>
                </div>

                <!-- Product Info -->
                <div class="col-lg-7">
                    <div class="product-info">
                        <h2 class="fw-bold mb-3" style="color:#222;"><?php echo e($product->product_name); ?></h2>
                        <p class="text-muted mb-5 pb-5"><?php echo $product->description; ?></p>
                        <div class="d-flex gap-3 mb-4">
                            <a href="#" class="btn btn-dark px-4 py-2 rounded-pill">
                                Inquiry now <i class="fa fa-info ms-2"></i>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Related Products -->
    <section class="related-products py-5">
        <div class="container">
            <h3 class="fw-bold text-center mb-5">You May Also Like</h3>
            <div class="row g-4">
                <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-6">
                        <div class="card border-0 shadow-sm">
                            <img src="<?php echo e(asset($rel->product_image ?? 'no-image.jpg')); ?>" class="card-img-top rounded-3"
                                alt="<?php echo e($rel->product_name); ?>">
                            <div class="card-body text-center">
                                <h6 class="fw-semibold mb-1"><?php echo e($rel->product_name); ?></h6>
                                <a href="<?php echo e(route('productdetail', [$product->category->strSlug ?? '', $rel->slug])); ?>"
                                    class="btn btn-sm btn-outline-dark rounded-pill">
                                    View
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function changeImage(element) {
            // get the clicked thumbnail's src
            const newSrc = element.getAttribute('src');

            // update main image
            const mainImage = document.getElementById('mainProductImage');
            if (mainImage) {
                mainImage.setAttribute('src', newSrc);
            }

            // remove 'active' class from all thumbnails
            document.querySelectorAll('.thumb-list img').forEach(img => {
                img.classList.remove('active');
            });

            // add 'active' to the clicked one
            element.classList.add('active');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/shivali/resources/views/frontview/product-detail.blade.php ENDPATH**/ ?>