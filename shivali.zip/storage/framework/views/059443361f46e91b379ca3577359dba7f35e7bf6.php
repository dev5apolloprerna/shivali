<?php $__env->startSection('title', isset($row) ? 'Edit Product' : 'Add Product'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content">
        <div class="page-content">
            <div class="container-fluid">

                
                <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                

                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0">Add Product</h4>
                            <div class="page-title-right">
                                <a href="<?php echo e(route('admin.products.index')); ?>"
                                    class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                    Back
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="live-preview">

          <form method="POST"
                action="<?php echo e(isset($row) ? route('admin.products.update',$row->product_id) : route('admin.products.store')); ?>"
                enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(isset($row)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

          
            
             <?php
                      $selectedCategory    = old('category_id', $row->category_id ?? '');
                      $selectedSubcategory = old('subcategory_id', $row->subcategory_id ?? '');
                    ?>
                    
                    <div class="row">
                      <div class="col-md-6 mb-3">
                        <label class="form-label">Category <span class="text-danger">*</span></label>
                        <select id="jsCategory"
                                name="category_id"
                                class="form-select <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                data-selected="<?php echo e($selectedCategory); ?>">
                          <option value="">-- Select Category --</option>
                          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php if($selectedCategory == $id): echo 'selected'; endif; ?>><?php echo e($name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    
                      <div class="col-md-6 mb-3">
                        <label class="form-label">Subcategory <span class="text-danger">*</span></label>
                        <select id="jsSubcategory"
                                name="subcategory_id"
                                class="form-select <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                data-selected="<?php echo e($selectedSubcategory); ?>"
                                <?php echo e($selectedCategory ? '' : 'disabled'); ?>>
                          <option value="">-- Select Subcategory --</option>
                          
                        </select>
                        <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-text" id="jsSubcatHelp" style="display:none;">Loading subcategories…</div>
                      </div>
                    </div>


            
            <div class="row">
              <div class="col-md-6 mb-3">
                <label class="form-label">Product Name <span class="text-danger">*</span></label>
                <input type="text"
                       name="product_name"
                       value="<?php echo e(old('product_name', $row->product_name ?? '')); ?>"
                       class="form-control <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       placeholder="Enter product name"
                       id="jsProductName">
                <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-text">
                  Slug: <span class="fw-semibold" id="jsSlugPreview">
                    <?php if(isset($row) && $row->slug): ?> <?php echo e($row->slug); ?> <?php else: ?> <span class="text-muted">Generated on save</span> <?php endif; ?>
                  </span>
                </div>
              </div>

             
              <div class="col-md-6 mb-3">
                <label class="form-label">
                  Product Image <?php echo e(isset($row) ? '(leave blank to keep)' : ''); ?>

                </label>
                <input type="file"
                       name="product_image" 
                       accept=".jpg,.jpeg,.png,.webp"
                       class="form-control <?php $__errorArgs = ['product_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['product_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <?php if(!empty($row?->product_image)): ?>
                  <div class="mt-2">
                    <img src="<?php echo e(asset($row->product_image)); ?>" alt="image" style="max-height: 90px;">
                  </div>
                <?php endif; ?>
              </div>

            </div>

            

            
            <div class="row">
                 <div class="col-md-12 mb-3">
                <label class="form-label">Description</label>
                 <textarea class="form-control ckeditor" name="description" id="description" rows="6"><?php echo e(old('description', $row->description ?? '')); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              </div>
            </div>


            <div class="card-footer mt-5" style="float: right;">
              <?php if(!isset($row)): ?>
                <button type="submit"  class="btn btn-primary btn-user float-right mb-3 mx-2">Save</button>
                <button class="btn btn-light float-right mr-3 mb-3 mx-2" type="reset">Clear</a>
                <?php else: ?>
                <button type="submit"  class="btn btn-primary btn-user float-right mb-3 mx-2">Update</button>
                <a class="btn btn-light float-right mr-3 mb-3 mx-2" href="<?php echo e(route('admin.products.index')); ?>">Cancel</a>

                <?php endif; ?>
            </div>

          </form>
        </div>
      </div>
</div>

    </div> 
  </div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.ckeditor.com/4.12.1/standard/ckeditor.js"></script>

<script>
(function () {
  const nameInput = document.getElementById('jsProductName');
  const preview   = document.getElementById('jsSlugPreview');
  if (!nameInput || !preview) return;

  function slugify(str) {
    return String(str || '')
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '')
      .substring(0, 190);
  }

  nameInput.addEventListener('input', function () {
    const v = this.value.trim();
    preview.textContent = v ? slugify(v) : 'Generated on save';
    if (!v) preview.classList.add('text-muted'); else preview.classList.remove('text-muted');
  });
})();


(function () {
  const catSel  = document.getElementById('jsCategory');
  const subSel  = document.getElementById('jsSubcategory');
  const helpTxt = document.getElementById('jsSubcatHelp');
  if (!catSel || !subSel) return;

  // Build route URL from your named route, replacing placeholder
  const ROUTE_TEMPLATE = <?php echo json_encode(route('admin.fetch-subcategories', ['category' => '__ID__']), 512) ?>;

  async function loadSubcategories(categoryId, preselectId) {
    // reset
    subSel.innerHTML = '<option value="">-- Select Subcategory --</option>';
    subSel.disabled = true;
    if (helpTxt) { helpTxt.style.display = 'inline'; helpTxt.textContent = 'Loading subcategories…'; }

    if (!categoryId) { if (helpTxt) helpTxt.style.display = 'none'; return; }

    const url = ROUTE_TEMPLATE.replace('__ID__', encodeURIComponent(categoryId));

    try {
      const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
      if (!res.ok) throw new Error('Bad response');
      const list = await res.json(); // [{iSubCategoryId, strSubCategoryName}, ...]

      for (const it of list) {
        const opt = document.createElement('option');
        opt.value = String(it.iSubCategoryId);
        opt.textContent = it.strSubCategoryName;
        if (preselectId && String(preselectId) === String(it.iSubCategoryId)) {
          opt.selected = true;
        }
        subSel.appendChild(opt);
      }

      subSel.disabled = false;
      if (helpTxt) helpTxt.style.display = 'none';
    } catch (err) {
      console.error(err);
      if (helpTxt) {
        helpTxt.style.display = 'inline';
        helpTxt.textContent = 'Failed to load subcategories. Please try again.';
      }
    }
  }

  // On first load (covers Edit + validation errors)
  const initialCategoryId    = catSel.getAttribute('data-selected') || catSel.value || '';
  const initialSubcategoryId = subSel.getAttribute('data-selected') || '';
  if (initialCategoryId) {
    loadSubcategories(initialCategoryId, initialSubcategoryId);
  }

  // On Category change
  catSel.addEventListener('change', function () {
    subSel.setAttribute('data-selected', ''); // clear previous
    loadSubcategories(this.value, '');
  });
})();

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/shivali/resources/views/admin/product/form.blade.php ENDPATH**/ ?>