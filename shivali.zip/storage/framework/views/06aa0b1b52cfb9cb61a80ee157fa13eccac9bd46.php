<?php $__env->startSection('title', 'Inquiry View'); ?>

<?php $__env->startSection('content'); ?>

    
    <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0"></h4>
                                <div class="page-title-right">
                                    <a href="<?php echo e(route('Inquiry.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Back</a>
                                </div>

                        </div>
                    </div>
                </div> 

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">

                            <div class="card-header">
                                <h5 class="card-title mb-0">Inquiry View</h5>

                            </div>
                            <div class="card-body">
                                <?php //echo date('ymd');
                                ?>
                                <table id="scroll-horizontal" class="table nowrap align-middle" style="width:100%">
                                        <tr>
                                            <td scope="col" width="10%">Name</th>
                                            <td><?php echo e($inquiry->name); ?></td>
                                        </tr>
                                        <tr>
                                            <td scope="col" width="10%">Mobile</th>
                                            <td><?php echo e($inquiry->mobileNumber); ?></td>
                                        </tr>
                                        <tr>
                                            <td scope="col" width="10%">Email</th>
                                                <td><?php echo e($inquiry->email); ?></td>
                                        </tr>
                                        <tr>
                                            <td scope="col" width="10%">Subject</th>
                                                <td><?php echo e($inquiry->subject); ?></td>
                                        </tr>
                                        <tr>
                                            <td scope="col" width="10%">Message</th>
                                                <td><?php echo e($inquiry->message); ?></td>
                                        </tr>
                                    
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/shivali/resources/views/admin/inquiries/view.blade.php ENDPATH**/ ?>